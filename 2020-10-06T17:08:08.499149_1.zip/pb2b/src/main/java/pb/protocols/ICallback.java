package pb.protocols;

@FunctionalInterface
public interface ICallback {
	/**
	 * Callback with no arguments.
	 */
	public void callback();
}
